package com.saludo.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestSaludoApplicationTests {

	@Test
	void contextLoads() {
	}

}
