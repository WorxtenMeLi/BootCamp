package com.numeroRomano.testRomano;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestRomanoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestRomanoApplication.class, args);
	}

}
