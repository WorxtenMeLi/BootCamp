package com.numeroRomano.testRomano;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestRomanoApplicationTests {

	@Test
	void contextLoads() {
	}

}
